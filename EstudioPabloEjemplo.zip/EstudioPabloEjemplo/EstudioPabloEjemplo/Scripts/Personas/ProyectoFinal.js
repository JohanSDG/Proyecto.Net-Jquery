﻿//evento inicial del JS
$(document).ready(function () {
    debugger;
    //evento de inicializacion
    modulo_Encuestas.init();   //aqui estoy llamandola funcion init del modulo
});


//Aqui estoy definiendo el modulo
var modulo_Encuestas = (function () {  //inicio del modulo

    //inicio del programa en JavaScript
    var init = function init() {

        $btnNuevo = $("#btnNuevo");
        $btnNuevo.click(eventoBotonNuevo);        //asigna un evento clic sobre el boton. en este caso ejecuta la funcion eventoBotonNuevo

        debugger;
        CargarListaDepartamentos();
    }

    //**************************************************


    //funcion que muestra un mensaje en pantalla
    function eventoBotonNuevo()
    {
        //abre el modal llamado myModal
        $('#myModal').modal("show");
    }

    function CargarListaDepartamentos() {
        var URL = '/ProyectoFinal/ConsultarDepartamentos';
                 //Controlador// Metodo o funcion!
        $.ajax(
            {
                type: 'post',
                data: null,  //paramtros
                dataType: 'json',
                url: URL,
                success: function (data) {
                    debugger;
                    $.each(data, function (index, optionData) {
                        $("#ddlDepartamentos").append("<option value='" + optionData.Id + "'>" + optionData.NombreDepartamento + "</option>");
                    });
                },
                error: function (error) {
                    //
                    console.log("ERROR EN CARGAR PRESENTACION " + error);
                    //
                    debugger;
                    alert(error.responseText);
                }
            });
    }


    //exponer las funciones hacia el exterior del modulo
    return {
        init: init
    };
})();  //fin de modulo modulo_Medicamentos
