﻿using EstudioPabloEjemplo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EstudioPabloEjemplo.Controllers
{
    public class ProyectoFinalController : Controller
    {
        // GET: ProyectoFinal
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]

        public JsonResult ConsultarDepartamentos()
        {

            string CadenaConexion = System.Configuration.ConfigurationManager.ConnectionStrings["Conexion"].ConnectionString;
            DataTable dataTable = new DataTable();
            string query = "select * from Departamentos";
            //La tabla de la base de datos adonde quiero referenciar.

            SqlConnection conn = new SqlConnection(CadenaConexion);
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();

            // create data adapter
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            // this will query your database and return the result to your datatable
            da.Fill(dataTable);
            conn.Close();
            da.Dispose();

            List<Departamentos> datos = Utilitario.ConvertTo<Departamentos>(dataTable);
            return Json(datos);
        }


    }

}